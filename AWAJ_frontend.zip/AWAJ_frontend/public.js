const reports = [
  {
    id: "#AJ-9921",
    category: "Education",
    text: "Absence of teachers at Kalanki Secondary School...",
    time: "2hrs ago"
  },
  {
    id: "#AJ-9922",
    category: "Education",
    text: "Lack of books in school library...",
    time: "3hrs ago"
  },
  {
    id: "#AJ-9923",
    category: "Education",
    text: "Poor classroom infrastructure...",
    time: "5hrs ago"
  },
  {
    id: "#AJ-9924",
    category: "Education",
    text: "Unclean school environment...",
    time: "1 day ago"
  }
];

const reportList = document.getElementById("report-list");

reports.forEach(report => {
  const div = document.createElement("div");
  div.classList.add("report-item");

  div.innerHTML = `
    <div>${report.id}</div>
    <div class="category">${report.category}</div>
    <div>${report.text}</div>
    <div class="time">${report.time}</div>
  `;

  reportList.appendChild(div);
});