const data = [
  {
    id: "#AJ-9921",
    category: "Education",
    summary: "Absence of teachers at Kalanki Secondary School...",
    location: "Kalanki, Kathmandu"
  },
  {
    id: "#AJ-8843",
    category: "Corruption",
    summary: "Bribe demand for citizenship processing...",
    location: "Lalitpur Ward 4"
  },
  {
    id: "#AJ-9922",
    category: "Health",
    summary: "Lack of medical staff in local clinic...",
    location: "Kalanki, Kathmandu"
  }
];

const tableBody = document.getElementById("table-body");

data.forEach(item => {

  let categoryClass = "";
  if (item.category === "Education") categoryClass = "education";
  if (item.category === "Corruption") categoryClass = "corruption";
  if (item.category === "Health") categoryClass = "health";

  const row = document.createElement("div");
  row.classList.add("table-row");

  row.innerHTML = `
    <div>${item.id}</div>
    <div><span class="tag ${categoryClass}">${item.category}</span></div>
    <div>${item.summary}</div>
    <div>${item.location}</div>
    <div class="action">View Details</div>
  `;

  tableBody.appendChild(row);
});