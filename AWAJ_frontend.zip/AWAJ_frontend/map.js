// Initialize map centered on Nepal
const map = L.map('map').setView([27.7, 85.3], 7);

// Tile layer (OpenStreetMap)
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 18
}).addTo(map);

let heatLayer;

// 🔥 Load heatmap data from API
async function loadHeatmap() {
  try {
    // Replace with your real API endpoint
    const response = await fetch('http://localhost:3000/api/grievances');
    const data = await response.json();

    /*
      Expected API format:
      [
        { "lat": 27.69, "lng": 85.28, "intensity": 0.9 },
        { "lat": 27.70, "lng": 85.30, "intensity": 0.7 }
      ]
    */

    const heatData = data.map(item => [
      item.lat,
      item.lng,
      item.intensity || 0.5
    ]);

    // Remove old layer
    if (heatLayer) {
      map.removeLayer(heatLayer);
    }

    // Add heatmap
    heatLayer = L.heatLayer(heatData, {
      radius: 25,
      blur: 15,
      maxZoom: 10
    }).addTo(map);

    // Optional: add markers
    data.forEach(item => {
      L.circleMarker([item.lat, item.lng], {
        radius: 5,
      }).addTo(map);
    });

  } catch (error) {
    console.error("Error loading heatmap:", error);
  }
}

// Load on start
loadHeatmap();