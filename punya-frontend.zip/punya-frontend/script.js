document.querySelector(".primary-btn").addEventListener("click", () => {
  alert("Redirecting to Report Page...");
});

document.querySelector(".secondary-btn").addEventListener("click", () => {
  alert("Opening Public Dashboard...");
});