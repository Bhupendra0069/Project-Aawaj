// FILE UPLOAD PREVIEW TEXT CHANGE
const fileInput = document.getElementById("fileInput");
const uploadText = document.querySelector(".upload-content p");

fileInput.addEventListener("change", () => {
  if (fileInput.files.length > 0) {
    uploadText.textContent = fileInput.files[0].name;
  }
});

// FAKE RECORD BUTTON TOGGLE
const recordBtn = document.getElementById("recordBtn");
let recording = false;

recordBtn.addEventListener("click", () => {
  recording = !recording;

  if (recording) {
    recordBtn.textContent = "⏹ Stop Recording";
    recordBtn.style.background = "#fecaca";
  } else {
    recordBtn.textContent = "🎤 Start Recording";
    recordBtn.style.background = "#e2e8f0";
  }
});